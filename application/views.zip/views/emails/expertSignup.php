<?php
/*
 * @author Visheshagya
 */
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Visheshagya - Password</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    </head>
    <body style="background:lightgray">
        <div align = "left">
            <img src="http://visheshagya.in/images/logo.png" style="width:15%">
            <p>Hello <?php echo $expertName . "<br/>"; ?></p>
            <p>Welcome to Visheshagya- India’s first online platform specifically for professionally qualified <b>CA's, CS, CMA and Lawyers</b>.</p>
            <p>Please login and update your personal and professional details.<br/>This will help us in verifying your account and also ensure that nobody else can impersonate and login to your account.
                <br/>The account validation gives you a higher chance of being searched more by the clients.</p>
            <p>URL : <?php echo $url . "<br/>"; ?></p>
            <p>Your user/login id: <b><?php echo $expertEmail . "<br/>"; ?></b> </p>
            <p>password: <b><?php echo $expertPassword . "<br/>"; ?></b></p>

            <p><b>Step 1 : Login</b></p>
            <p><b>Step 2 : Complete Your Personal and Professional Information</b></p>
            <p><b>Step 3 : Upload Mandatory Document</b></p>
            <p><b>Step 4 : Set Consultation Details</b></p>
            <p><b>You are now ready to Go..</b></p>
            <p>We look forward to have a rewarding and long- term association with you.</p>
            <p>Have a wonderful experience. </p>
            <p><em>Team Visheshagya</em></p>
            <p><em> Services Redefined</em></p>
            <p>
            </p>
        </div>
    </body>
</html>

