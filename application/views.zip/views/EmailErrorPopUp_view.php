<?php
/*
 * @author Visheshagya
 */
?>
<div id="emailError" class="modal fade error-popup" style="display:none">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" data-dismiss="modal" aria-hidden="true"> <i class="fa fa-times-circle-o"></i></button>
            </div>                    
            <div class="modal-body">
                <fieldset>
                    <legend>Sign Up Error</legend>
                    <p><?php echo "Entered email id is already registered with us."; ?></p>
                </fieldset>
            </div>
        </div>
    </div>
</div>
