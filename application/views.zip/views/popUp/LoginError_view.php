<?php
/*
 * @author Avinash Raj
 */
?>

<!-- to display the sign up pop up -->
<div id="LoginError" class="modal fade  error-popup" style="display:none;">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" data-dismiss="modal" aria-hidden="true"> <i class="fa fa-times-circle-o"></i></button>
            </div>                    
            <div class="modal-body">
                <fieldset>
                    <legend>OPPs</legend>
                    <p>Please provide  valid Email Id and Password</p>       
                </fieldset>
            </div>
        </div>
    </div>
</div>
<!--End -->
