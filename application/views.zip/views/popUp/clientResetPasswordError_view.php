<?php
/*
 * @author Avinash Raj
 */
?>

<!-- to display the sign up pop up -->
<div id="clientResetPasswordError" class="modal fade error-popup" style="display:none;">
    <div class="modal-dialog">
            <div class="modal-header">
                <button type="button" data-dismiss="modal" aria-hidden="true"> <i class="fa fa-times-circle-o"></i></button>
            </div> 
            <div class="modal-body">                   
                <fieldset>
                    <legend>OOPs</legend>
                    <p>Please enter valid Email Id and Mobile Number</p>
                </fieldset>
        </div>
    </div>
</div>
<!--End -->
