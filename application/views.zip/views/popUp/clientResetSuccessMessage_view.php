<?php
/*
 * @author Avinash Raj
 */
?>

<!-- to display the sign up pop up -->
<div id="resetSuccessMessage" class="modal fade sucess-modal" style="display:none;">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button"> <i class="fa fa-check"></i></button>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            </div>                    
            <div class="modal-body">
                <fieldset>
                    <legend>Password reset successfully</legend>
                    <p>Your password has been sent to the registered Email Id</p>
<!--                     <p>You shall be receiving the mail within 15 minutes</p>
                    <p>Please check your SPAM/JUNK mail folder also for the same.</p> -->
                </fieldset>
            </div>
        </div>
    </div>
</div>
<!--End -->

