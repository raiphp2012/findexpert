<?php
/*
 * @author Visheshagya
 */
?>
<div id="noAppointmentRecord" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            </div>                    
            <div class="container">
                <fieldset>
                    <legend>No Record Found</legend>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="form-group">
                                <label for="inputEmail" class="col-lg-12 control-label">No Appointment record has been found so you will not be able to share any files as of now</label>
                            </div>
                        </div>
                        <div class="col-lg-6">
                        </div>
                    </div>
                </fieldset>
                <!--</form>-->
            </div>
        </div>
    </div>
</div>