<?php
/*
 * @author Visheshagya
 */
?>

<!-- to display the sign up pop up -->
<div id="signupSuccessMessage" class="modal fade sucess-modal" style="display:none;">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button"> <i class="fa fa-check"></i></button>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            </div>                    
            <div class="modal-body">
                <fieldset>
                    <legend>CONGRATULATIONS, Signed Up Successful</legend>
                        <p><b>Thank you</b> for signing up with Visheshagya</p>
                        <p>Your password has been sent to the email provided</p>
                  <!--       <p>You shall be receiving the mail within 15 minutes.</label><br/>
                        <p>Please check your <b>INBOX/SPAM/JUNK</b> mail folder also for the same</p> -->
                </fieldset>
            </div>
        </div>
    </div>
</div>