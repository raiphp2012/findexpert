<?php
/*
 * @author Avinash Raj
 */
?>

<!-- to display the sign up pop up -->
<div id="showProfileData" class="modal fade" style="display:none;">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            </div>                    
            <div class="container">
                <fieldset>
                                        <legend style="display: block;
                                                width: 100%;
                                                padding: 0;
                                                margin-bottom: 20px;
                                                font-size: 21px;
                                                line-height: inherit;
                                                color: #333;
                                                border: 0;
                                                border-bottom: 1px solid #e5e5e5;" id="expertName"></legend>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="form-group">
                                <label class="col-lg-12 control-label"></label>
                                <p id="profileData">
                                    
                                </p>
                                <br/><br/>
                            </div>
                        </div>
                    </div>
                </fieldset>
            </div>
        </div>
    </div>
</div>
<!--End -->
