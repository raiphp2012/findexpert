<?php
/*
 * @author Avinash Raj
 */
?>

<!-- to display the sign up pop up -->
<div id="changeSuccessMessage" class="modal fade sucess-modal" style="display:none;">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
               <button type="button"> <i class="fa fa-check"></i></button>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            </div>                    
            <div class="modal-body">
                <fieldset>
                    <legend>Sucess</legend>
                    <p>Password changed successfully</p>
                </fieldset>
            </div>
        </div>
    </div>
</div>
<!--End -->
