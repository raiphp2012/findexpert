<?php
/*
 * @author Visheshagya
 */
?>
<li>
    <div class = "dropdown">
        <a class = "btn dropdown-toggle" data-toggle = "dropdown" href = "#">
            <span class = "login-icon pull-left"></span>
        </a>
        <ul class = "dropdown-menu" role = "menu" aria-labelledby = "menu1">
            <li role = "presentation" class = "dropdown-header"></li>
            

           
            <li><a href = "<?php echo base_url() ?>ClientHome/logout"   class = "btn btn-danger btn-xs" role = "button" data-toggle = "modal">Logout</a></li>
            <li></li>
        </ul>
    </div>
</li>
