<footer id="footer">
    <div class="row copywright" style="text-align: center; padding: 0 20px 20px;">
        <div class="col-md-12" style="padding: 20px 0;">
            <a href="https://www.facebook.com/visheshagya" target="_blank" style="border-radius: 50%;background-color: #3b5998;padding: 10px 15px;"><i class="fa fa-facebook"></i></a>
            <a href="https://twitter.com/Visheshagya_IN" target="_blank" style="border-radius: 50%;background-color: #0084b4;padding: 10px 12px;"><i class="fa fa-twitter"></i></a>
        </div>
        <div class="col-md-12">
            <!-- <a href="http://visheshagya.in">  Visheshagya.in</a> | --> <a href="<?php echo base_url(); ?>Contact">Contact Us</a> | <a href="http://visheshagya.in/blog"> Blog</a>   |  <a href="<?php echo base_url(); ?>ExpertTermsAndCondition">Terms of Use</a> | <a href="<?= base_url() ?>Privacy">Privacy Policy</a> 
        </div>
        <div class="col-md-12" style="padding-top: 10px; font-size: 14px;">2016 &copy; Visheshagya Services Pvt Ltd | All rights reserved</div>
    </div>
</footer>