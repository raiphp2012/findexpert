
  <footer id="footer" class="fullWidthSection greyColor">
    <div class="container">
      <div class="row">
        <div class="col-md-6 col-sm-6">
          <ul class="list-inline social-buttons">
            <li>Follow Us On:</li>
            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
          </ul>

        </div>
        <div class="col-md-6 col-sm-6 textright">
          Visheshagya.in  |  <a href="">Terms of Use</a> | <a href="">Privacy Policy</a>
        </div>
      </div>
    </div>
  </footer>

	<!-- script references -->
	<script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
    
    <script src="<?php echo base_url(); ?>assets1/js/bootstrap.min.js"></script>  
    <script src="<?php echo base_url(); ?>assets1/js/matchheight.js"></script>
    <script src="<?php echo base_url(); ?>assets1/js/typeit.min.js"></script>
    <script src="<?php echo base_url(); ?>assets1/js/bootstrap-slider.js"></script>
    <script src="<?php echo base_url(); ?>assets1/js/readmore.min.js"></script>
    <script src="<?php echo base_url(); ?>assets1/js/site.js"></script>	
	</body>
</html>