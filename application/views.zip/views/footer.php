<footer id="footer">
                <div class="container">
                    <div class="row">
                        <div class="col-md-4">
                            <h1 class="address">Follow On Facebook</h1>
                           <div class="fb-page" data-href="https://www.facebook.com/visheshagya" data-tabs="timeline"  data-height="400" data-small-header="true" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/visheshagya" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/visheshagya">Visheshagya</a></blockquote></div>

                        </div>
                        <div class="col-md-4">
                            <h1 class="address">Follow On Twitter</h1>
                            <a class="twitter-timeline" data-height="400"data-theme="light" data-link-color="#2B7BB9" href="https://twitter.com/Visheshagya_IN">Tweets by Visheshagya_IN</a> <script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>
                        </div>
                        <div class="col-md-4">
                            <h1 class="address">Contact Us</h1>
                            <h2 class="company-name">Visheshagya Services Pvt. Ltd.</h2>
                            <div class="contact">
                                <p><i class="fa fa-envelope-o"></i>support@visheshagya.in</p>
                                <p><i class="fa fa-phone"></i>786-2800-600</p>
                                <p><i class="fa fa-building"></i>Head Office</p>
                                <div class="head-office">
                                    <p>Visheshagya Services Pvt. Ltd</p>
                                    <p>C-1291, Sushant Lok-I</p>
                                    <p>Gurugram- 122009</p>
                                </div>
                                <p><i class="fa fa-map-marker"></i>Navigate</p>
                               <iframe
                                  width="100%"
                                  height="170"
                                  frameborder="0" style="border:0" scrolling="no"
                                  src="https://www.google.com/maps/embed/v1/place?key=AIzaSyC7GJBy30ewQjoUIy6CCZ1qRcjeceZrjDw
                                    &q=28.4555718,77.0854122">
                                </iframe>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row copywright">
                        <div class="col-md-6">&copy; Visheshagya Services Pvt Ltd | All rights reserved</div>
                        <div class="col-md-6" style="text-align: right">
                            <!-- <a href="http://visheshagya.in">  Visheshagya.in</a> | --> <a href="http://visheshagya.in/blog"> Blog</a>   |  <a href="<?php echo base_url(); ?>ExpertTermsAndCondition">Terms of Use</a> | <a href="<?= base_url() ?>Privacy">Privacy Policy</a> 
                        </div>
                    </div>
            </footer>